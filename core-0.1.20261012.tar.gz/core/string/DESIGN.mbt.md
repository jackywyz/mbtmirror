# `String`

## Overview

* **UTF-16 Encoding**: MoonBit strings use UTF-16 encoding, which means
  characters outside the Basic Multilingual Plane (such as emojis) are
  represented using surrogate pairs - two 16-bit code units.

* **Well-formedness**: every `String` and `StringView` must be well-formed
  UTF-16: each surrogate is part of a pair, and no view starts or ends between
  the two halves of a pair. Library code may rely on this contract without
  re-checking it; for example, `escape` copies unescaped runs without
  re-validating their boundaries. The checked APIs (`exact_view`, `get_view`,
  the clamping `s[i:j]`) enforce it. Unchecked APIs leave it to the caller:
  `view` takes raw code-unit offsets and does not check surrogate boundaries,
  and `unsafe_to_char` must not be given a surrogate code point, so a
  supplementary character has to be written as one `Char`, never as two
  halves. An ill-formed string or view is outside the contract.

* **Char vs Charcode**: MoonBit distinguishes between:
  - `Charcode`: A UTF-16 code unit (type `UInt16`)
  - `Char`: A Unicode character (type `Char`)

* **Indexing**: There are two ways to count or index elements in a string:
  - **Offset** or **Charcode Index**: UTF-16 index (counts code units)
  - **Character Index**: Counts actual Unicode characters

  Because of the complexity of UTF-16 indexing, unlike `Array` or `Bytes`, we
  have specific guidelines for string indexing:
  - The `s[i]` syntax is available but should be used with caution. It accesses
    the i-th UTF-16 code unit (charcode) for efficiency and consistency with
    other APIs. The return type of `s[i]` is `UInt16`, which reminds you that it
    returns the charcode.
  - The slice operator `s[i:j]` uses UTF-16 code-unit indices. It clamps both
    bounds to `[0, s.length()]`, trims split surrogate pairs inward, and
    returns an empty view for an inverted range. Negative bounds clamp to
    zero. Use `s.exact_view(start=i, end=j)` to require valid bounds and surrogate
    boundaries, or `s.get_view(start=i, end=j)` to return `None` when they are
    invalid. Use `s.split_at(i)` for a lossless split; two slices `s[:i]` and
    `s[i:]` both omit a character split by `i`.

* **Performance and Unicode Safety**:
  - Most APIs in this package operate on UTF-16 offsets rather than Unicode
    characters for efficiency. Offset-based operations have O(1) complexity
    while character-based operations typically require O(n) scanning. However,
    direct offset manipulation is not unicode-safe as it may split surrogate
    pairs. For example,
    * `get_char(i)` reads the data at the i-th offset and returns the
      corresponding character (or `None` if that offset splits a surrogate
      pair), while `at(i)` (a.k.a. `code_unit_at(i)`) returns the charcode at
      that offset. Both APIs take O(1) time complexity.
    * `find` and `rev_find` will return the charcode index if the target is
      found. The index can be used to create a view of the string.
  - For unicode-safe operations, it's recommended to use:
    - Iterators: `str.iter()` yields proper Unicode characters
    - Pattern matching: Handles surrogate pairs correctly
  - Example of safe vs unsafe operations:
```mbt check
///|
test "unsafe vs safe" {
  // Unsafe: raw offsets may land in the middle of a surrogate pair
  let emoji = "🎉"
  let _ = emoji.get_char(1) // None: offset 1 is the second half of the pair
  // Safe: Uses iterator
  for c in "Hello 🌍".iter() {
    // Properly handles both ASCII and Unicode chars
    ignore(c)
  }
}
```

* **Validity**: Strings store UTF-16 code units. `exact_view` validates bounds and
  surrogate boundaries, while `clamped_view` trims split pairs inward. Unsafe
  APIs can still build an ill-formed string (e.g.,
  `"🍎".unsafe_substring(start=1, end=2)` starts at the second half of a
  surrogate pair); that breaks the well-formedness contract above, and the
  library's behavior on such strings is unspecified.

* **View**: A `StringView` represents a window into a string. Slice syntax and
  `exact_view` preserve character boundaries, while the `view` method takes raw
  UTF-16 offsets without checking them, so its caller must not split a
  surrogate pair. Views are
  designed to be more performant than creating new String instances when working
  with substrings.

  - **Performance**: Views are more performant than creating new String instances
    when working with substrings. They avoid string copying and memory allocation
    by maintaining references to the original string with start and end offsets,
    making substring operations O(1) rather than O(n). Multiple views of the same
    string share the underlying memory, which is particularly beneficial when
    processing large texts or creating many substring operations.

  - **Implicit Conversion**: String can be implicitly converted to View when
    the context is clear. This allows seamless interoperability between String
    and View in function calls where the expected type is unambiguous.

  - **API Parameter Design**: In string APIs, we use View as parameter types
    because when calling functions, the context (expected type) for arguments
    is mostly clear. This design allows both String and View to be passed to
    functions expecting View parameters, leveraging implicit conversion.

```mbt check
///|
test "view conversion" {
  fn process_text(text : StringView) -> Int {
    text.length()
  }

  let str = "Hello World"
  let view = str.exact_view(start=0, end=5)

  // Both work due to implicit conversion
  let _ = process_text(str) // String implicitly converts to View
  let _ = process_text(view)
  // Direct View usage
}
```

  - **Return Type Strategy**: The return type depends on the nature of the
    operation and the input type:

    * **Substring Operations** (like `trim`, `split`): Always return `View` or
      `Iter[View]` because these operations create subparts of the original
      String. Using `View` is more efficient as it avoids copying.

    * **Transformation Operations** (like `replace`, `to_upper`): Return type
      matches the input type. If called on `View`, returns `View`; if called on
      `String`, returns `String`. This preserves type consistency and user
      intent.

  - **Unicode Safety and Validity**: Use slice syntax or `exact_view` to avoid
    splitting surrogate pairs. These operations validate the boundaries, not
    every code unit inside the input. A view can still contain invalid UTF-16
    inherited from an unchecked string or a raw `view` call.
